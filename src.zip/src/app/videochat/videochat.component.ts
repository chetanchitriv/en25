import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videochat',
  templateUrl: './videochat.component.html',
  styleUrls: ['./videochat.component.css']
})
export class VideoChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
