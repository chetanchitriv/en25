import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { NgxSpinnerService } from "ngx-spinner";
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
@Component({
  //selector: 'app-screen2',
  templateUrl: './start-consultation.component.html',
  styleUrls: ['./start-consultation.component.css']
})
export class StartConsultationComponent implements OnInit {
  loading:boolean=false
  constructor(private router: Router,
    private ngxService: NgxUiLoaderService,
   private SpinnerService: NgxSpinnerService) { }

  ngOnInit(): void {
  
    
  }
  save(){
   
   this.router.navigate(['agent-list'])
 
  }

  ngOnDestroy() {
    var element = document.getElementsByClassName("modal-backdrop");
    if (element.length > 0) {
      // if it finds any blackdrop view at the back it will remove that
      element[0].remove();
    }
  }

}
