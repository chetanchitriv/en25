import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
@Component({
  //selector: 'app-',
  templateUrl: './no-available-agent.component.html',
  styleUrls: ['./no-available-agent.component.css']
})
export class NoAvailableAgentComponent implements OnInit {

  constructor(private router: Router,
    private ngxService: NgxUiLoaderService,) {}


  ngOnInit(): void {
    this.ngxService.start(); // start foreground spinner of the master loader with 'default' taskId
    // Stop the foreground loading after 5s
   
      setTimeout(() => {
        this.ngxService.stop();
      }, 5000);
  }


  home(){
    this.router.navigate(['start-consultation'])
  }
}
