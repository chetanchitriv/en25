import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { VideoChatComponent } from './videochat/videochat.component';
import {RouterModule, Routes} from "@angular/router";
import { ConnectingComponent } from './connecting/connecting.component';
import { NoAvailableAgentComponent } from './no-available-agent/no-available-agent.component';
import { StartConsultationComponent } from './start-consultation/start-consultation.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxUiLoaderModule } from "ngx-ui-loader";
const routes: Routes = [
  {path: '' , redirectTo:'start-consultation', pathMatch: 'full'},
  {path: 'no-available-agent', component: NoAvailableAgentComponent},
  {path: 'start-consultation', component: StartConsultationComponent},
  {path: 'connecting', component: ConnectingComponent},
  {path: 'videochat', component: VideoChatComponent},
  {path: 'agent-list', component: AgentListComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    NoAvailableAgentComponent,
    StartConsultationComponent,
    ConnectingComponent,
    VideoChatComponent,
    AgentListComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    BrowserModule,
    NgxSpinnerModule,
    NgxUiLoaderModule,
    HttpClientModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
