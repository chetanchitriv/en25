import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { Router } from '@angular/router';
@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.css']
})
export class AgentListComponent implements OnInit {
  agentList=[]
  employeeData:any;
    constructor(private httpClient: HttpClient,
      private ngxService: NgxUiLoaderService,
      private router: Router,) { }
  
    ngOnInit(): void {
     
      this.ngxService.start(); // start foreground spinner of the master loader with 'default' taskId
      // Stop the foreground loading after 5s
     
        setTimeout(() => {
          this.ngxService.stop();
        }, 5000);
       this.httpClient.get<any>("assets/agent.json").subscribe((data)=>{

     
        this.employeeData = data
        if(this.employeeData.length){
          this.router.navigate(['no-available-agent'])
        }
       }
      )
  
    }
   
}
