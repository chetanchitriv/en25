import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connecting',
  templateUrl: './connecting.component.html',
  styleUrls: ['./connecting.component.css']
})
export class ConnectingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
